import { VIEW_ORDER } from './shared/constants.js';
import {
  getState,
  patchState,
  pushHistory,
  resetHistory,
  runAction,
  seedDemoState,
  setActiveView,
  setLastRunMode,
  setSimulationValue,
  subscribe,
} from './services/runtimeTruth.js';
import { renderDefinitionList, renderHistory } from './services/renderers.js';
import { renderInitView } from './views/initView.js';
import { renderTestView } from './views/testView.js';
import { renderLastRunView } from './views/lastRunView.js';
import { renderRunningProcessView } from './views/runningProcessView.js';

const app = document.getElementById('app');

function render() {
  const state = getState();
  const viewMarkup = {
    A: renderInitView(state),
    B: renderTestView(state),
    C: renderLastRunView(state),
    D: renderRunningProcessView(state),
  }[state.activeView];

  app.innerHTML = `
    <div class="shell">
      <aside class="sidebar">
        <div class="brand-card">
          <p class="eyebrow">Photo frame operator workspace</p>
          <h1>Control Dashboard</h1>
          <p class="brand-copy">A higher-clarity unwired frontend built for later backend wiring, with stronger separation between setup, testing, recovery, and real runtime monitoring.</p>
        </div>

        <nav class="nav-card" aria-label="Views">
          ${VIEW_ORDER.map(
            (view) => `
              <button class="nav-link ${state.activeView === view.id ? 'nav-link--active' : ''}" data-view="${view.id}">
                <span class="nav-link__code">${view.id}</span>
                <span class="nav-link__body"><strong>${view.name}</strong><small>${view.subtitle}</small></span>
              </button>
            `,
          ).join('')}
        </nav>

        <article class="side-panel">
          <div class="side-panel__header">
            <h2>Current truth</h2>
            <span class="pill">Mock</span>
          </div>
          ${renderDefinitionList({
            'Source of truth': state.truth.sourceOfTruth,
            'Queue length': String(state.truth.queueLength),
            'Current media': state.truth.currentMedia?.name ?? 'None',
            'Playback status': state.truth.playbackStatus,
            'Screen state': state.truth.screenState,
            'Last activity': state.truth.lastActivitySource,
            'Timeout': `${state.truth.inactivityTimeoutSeconds}s`,
            'Last checkpoint': state.truth.lastCheckpoint,
            'Last stage': state.truth.lastStageCompleted,
            'Stage lock': state.truth.stageLock,
            'Playback lock': state.truth.playbackLock,
            'Screen lock': state.truth.screenLock,
          })}
        </article>

        <article class="side-panel side-panel--history">
          <div class="side-panel__header">
            <h2>Event history</h2>
            <button class="button button--ghost" data-action="clear-history">Clear</button>
          </div>
          <div class="history-surface">${renderHistory(state.history)}</div>
        </article>
      </aside>

      <main class="main-panel">
        <header class="topbar">
          <div>
            <p class="eyebrow">${state.modeBanner}</p>
            <h1>${state.currentViewTitle}</h1>
          </div>
          <div class="topbar__actions">
            <button class="button button--secondary" data-action="seed-demo">Seed demo state</button>
            <button class="button button--primary" data-action="start-real-run">Start real run</button>
          </div>
        </header>
        ${viewMarkup}
      </main>
    </div>
  `;

  bindEvents();
}

function bindEvents() {
  app.querySelectorAll('[data-view]').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.view;
      const label = VIEW_ORDER.find((view) => view.id === id);
      setActiveView(id, `${id} — ${label?.name ?? ''}`);
    });
  });

  app.querySelectorAll('[data-action]').forEach((button) => {
    button.addEventListener('click', () => {
      const action = button.dataset.action;
      if (action === 'clear-history') {
        resetHistory();
        return;
      }
      if (action === 'seed-demo') {
        seedDemoState();
        return;
      }
      if (action === 'start-real-run') {
        runAction('start-real-run');
        return;
      }
      runAction(action);
    });
  });

  app.querySelectorAll('input[name="execution-mode"]').forEach((input) => {
    input.addEventListener('change', (event) => setSimulationValue('executionMode', event.target.value));
  });

  app.querySelectorAll('input[name="input-mode"]').forEach((input) => {
    input.addEventListener('change', (event) => setSimulationValue('inputMode', event.target.value));
  });

  ['pirEnabled', 'mouseEnabled', 'keyboardEnabled', 'simulateAllEnabled'].forEach((name) => {
    app.querySelectorAll(`input[name="${name}"]`).forEach((input) => {
      input.addEventListener('change', (event) => {
        const checked = event.target.checked;
        setSimulationValue(name, checked);
        pushHistory('SCREEN', 'info', `${name} changed to ${checked ? 'enabled' : 'disabled'}.`);
      });
    });
  });

  app.querySelectorAll('input[name="inactivityTimeoutSeconds"]').forEach((input) => {
    input.addEventListener('change', (event) => {
      const value = Number(event.target.value || 5);
      setSimulationValue('inactivityTimeoutSeconds', value);
      pushHistory('SCREEN', 'info', `Inactivity timeout changed to ${value} seconds.`);
    });
  });

  app.querySelectorAll('[data-last-run-mode]').forEach((button) => {
    button.addEventListener('click', () => {
      const mode = button.dataset.lastRunMode;
      setLastRunMode(mode);
      if (mode === 'ready') {
        seedDemoState();
      }
      if (mode === 'error') {
        patchState((draft) => {
          draft.lastRunMode = 'error';
        });
      }
      if (mode === 'none') {
        patchState((draft) => {
          draft.lastRunMode = 'none';
          draft.lastRunData = { media: {}, playback: {}, stage: {}, screen: {} };
        });
      }
    });
  });
}

subscribe(render);
render();
