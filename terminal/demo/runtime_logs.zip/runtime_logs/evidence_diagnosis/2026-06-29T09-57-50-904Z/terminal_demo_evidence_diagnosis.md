# Terminal Demo Evidence Diagnosis — BLOCKED

- Repo version: 0.15.1
- Evidence source: S:\_PHOTOFRAMES\PF_login_v0.10.20_github_history_merged\terminal\demo\runtime_logs\operator_rehearsal\2026-06-29T09-57-50-684Z\terminal_demo_operator_rehearsal_0.15.1_2026-06-29T09-57-50-684Z.zip
- Evidence status: BLOCKED
- Failed checks: 3

## Issues
- BLOCKED — NODE_DEPENDENCIES_MISSING: Node dependencies appear missing or incomplete.
  - Evidence: vite/tsx/module resolution error found in evidence.
  - Next: Run npm install from the PhotoFrame repo root, then rerun VERIFY_TERMINAL_DEMO.CMD.
- BLOCKED — NODE_OR_NPM_NOT_ON_PATH: Node.js or npm was not available on PATH.
  - Evidence: Node/npm/ENOENT error found in evidence.
  - Next: Install Node.js/npm or fix PATH, then rerun the verifier.
- BLOCKED — ZIP_ROOT_VERSION_MISMATCH: Extracted folder name does not match VERSION.
  - Evidence: folder=PF_login_v0.10.20_github_history_merged; exit=1; Group 6B final proof invokes terminal/demo/scripts/verify-smoke.mjs.
  - Next: Extract the latest generated ZIP without renaming its root folder, or set TERMINAL_DEMO_ALLOW_WORK_FOLDER_NAME=1 only for local worktrees.
- BLOCKED — FAILED_CHECK_repo-folder-name-matches-version: Failed check: repo folder name matches version
  - Evidence: folder=PF_login_v0.10.20_github_history_merged
  - Next: Open terminal_demo_status.md and the referenced command log, then rerun this diagnosis after fixing the blocker.
- BLOCKED — FAILED_CHECK_terminal-demo-final-proof-passes: Failed check: terminal demo final proof passes
  - Evidence: exit=1
  - Next: Open terminal_demo_status.md and the referenced command log, then rerun this diagnosis after fixing the blocker.
- BLOCKED — FAILED_CHECK_terminal-demo-merge-smoke-is-covered-by-final-pr: Failed check: terminal demo merge smoke is covered by final proof
  - Evidence: Group 6B final proof invokes terminal/demo/scripts/verify-smoke.mjs.
  - Next: Open terminal_demo_status.md and the referenced command log, then rerun this diagnosis after fixing the blocker.

## Next action
Run npm install from the PhotoFrame repo root, then rerun VERIFY_TERMINAL_DEMO.CMD.
