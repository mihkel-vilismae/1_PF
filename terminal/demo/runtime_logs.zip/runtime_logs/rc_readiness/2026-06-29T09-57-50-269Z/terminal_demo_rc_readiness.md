# Terminal Demo RC Readiness — BLOCKED

- Version: 0.15.1
- Evidence folder: terminal/demo/runtime_logs/rc_readiness/2026-06-29T09-57-50-269Z
- RC decision: NOT_RC1

## Commands
- BLOCKED — terminal-demo-final-proof: C:\nvm4w\nodejs\node.exe tools/run-terminal-demo-final-guard-proof.mjs final → terminal/demo/runtime_logs/rc_readiness/2026-06-29T09-57-50-269Z/terminal-demo-final-proof.log
- BLOCKED — terminal-demo-operator-rehearsal: C:\nvm4w\nodejs\node.exe tools/run-terminal-demo-operator-rehearsal.mjs → terminal/demo/runtime_logs/rc_readiness/2026-06-29T09-57-50-269Z/terminal-demo-operator-rehearsal.log
- BLOCKED — terminal-demo-evidence-diagnosis: C:\nvm4w\nodejs\node.exe tools/run-terminal-demo-evidence-diagnosis.mjs terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T09-57-50-684Z/terminal_demo_operator_rehearsal_0.15.1_2026-06-29T09-57-50-684Z.zip → terminal/demo/runtime_logs/rc_readiness/2026-06-29T09-57-50-269Z/terminal-demo-evidence-diagnosis.log

## Checks
- PASS — VERSION and package.json match — VERSION=0.15.1; package=0.15.1
- BLOCKED — v0.15.0 milestone version is active — VERSION=0.15.1
- PASS — root operator verifier exists — VERIFY_TERMINAL_DEMO.CMD
- PASS — root RC verifier exists — VERIFY_TERMINAL_DEMO_RC.CMD
- PASS — evidence diagnosis launcher exists — ANALYZE_TERMINAL_DEMO_EVIDENCE.CMD
- PASS — npm script is discoverable: proof:terminal-demo-final — node tools/run-terminal-demo-final-guard-proof.mjs final
- PASS — npm script is discoverable: proof:terminal-demo-operator-rehearsal — node tools/run-terminal-demo-operator-rehearsal.mjs
- PASS — npm script is discoverable: terminal-demo:evidence-diagnosis — node tools/run-terminal-demo-evidence-diagnosis.mjs
- PASS — npm script is discoverable: proof:terminal-demo-evidence-diagnosis — node tools/run-terminal-demo-evidence-diagnosis.mjs --self-test
- PASS — npm script is discoverable: proof:terminal-demo-rc-readiness — node tools/run-terminal-demo-rc-readiness-audit.mjs
- PASS — npm script is discoverable: demo:terminal:real:smoke — tsx terminal/demo/src/main.ts --adapter=real-demo --real-demo-smoke
- PASS — npm script is discoverable: demo:terminal:mock:smoke — tsx terminal/demo/src/main.ts --adapter=mock-demo --smoke
- PASS — operator verifier prints PASS/BLOCKED outcomes — VERIFY_TERMINAL_DEMO.CMD has clear terminal summary wording.
- PASS — RC verifier prints PASS/BLOCKED outcomes — VERIFY_TERMINAL_DEMO_RC.CMD has clear terminal summary wording.
- PASS — terminal README documents RC audit command — terminal/demo/README.md
- PASS — OpenSpec documents RC readiness gate — terminal demo OpenSpec
- BLOCKED — final guard proof passes — exit=1
- BLOCKED — operator rehearsal command passes — exit=1; status=BLOCKED
- PASS — operator rehearsal produced evidence ZIP — terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T09-57-50-684Z/terminal_demo_operator_rehearsal_0.15.1_2026-06-29T09-57-50-684Z.zip
- BLOCKED — evidence diagnosis command passes on rehearsal evidence — exit=1; status=BLOCKED
- PASS — evidence diagnosis writes reports — {"jsonPath":"terminal/demo/runtime_logs/evidence_diagnosis/2026-06-29T09-57-50-904Z/terminal_demo_evidence_diagnosis.json","markdownPath":"terminal/demo/runtime_logs/evidence_diagnosis/2026-06-29T09-57-50-904Z/terminal_demo_evidence_diagnosis.md"}
- PASS — RC evidence folder excludes source files — Only logs/status files are written under rc_readiness.
