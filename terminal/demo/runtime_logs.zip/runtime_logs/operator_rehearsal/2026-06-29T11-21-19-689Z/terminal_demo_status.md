# Terminal Demo Operator Rehearsal — BLOCKED

- Version: 1.0.0
- Repo folder: PF_login_v0.10.20_github_history_merged
- Evidence folder: terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T11-21-19-689Z
- Evidence ZIP: terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T11-21-19-689Z/terminal_demo_operator_rehearsal_1.0.0_2026-06-29T11-21-19-689Z.zip

## Commands
- PASS — terminal-demo-final-proof: `C:\nvm4w\nodejs\node.exe tools/run-terminal-demo-final-guard-proof.mjs final` → terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T11-21-19-689Z/terminal-demo-final-proof.log

## Checks
- PASS — VERSION is readable — VERSION=1.0.0
- PASS — package.json version matches VERSION — package.json=1.0.0
- BLOCKED — repo folder name matches version — folder=PF_login_v0.10.20_github_history_merged
- PASS — Windows terminal runner exists — terminal/demo/windows_runner.cmd
- PASS — root verification launcher exists — VERIFY_TERMINAL_DEMO.CMD
- PASS — terminal verification launcher exists — terminal/demo/windows_verify_terminal_demo.cmd
- PASS — operator rehearsal script is registered — package.json script
- PASS — evidence diagnosis launcher exists — ANALYZE_TERMINAL_DEMO_EVIDENCE.CMD
- PASS — evidence diagnosis script is registered — package.json script
- PASS — runner diagnostics mention PhotoFrame repo and final proof — Windows runner prints repo root and verification command.
- PASS — terminal demo final proof passes — exit=0
- PASS — terminal demo merge smoke is covered by final proof — Group 6B final proof invokes terminal/demo/scripts/verify-smoke.mjs.
- PASS — terminal-demo-only evidence ZIP exists — terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T11-21-19-689Z/terminal_demo_operator_rehearsal_1.0.0_2026-06-29T11-21-19-689Z.zip
- PASS — evidence ZIP is inside terminal/demo/runtime_logs/operator_rehearsal — terminal/demo/runtime_logs/operator_rehearsal/2026-06-29T11-21-19-689Z/terminal_demo_operator_rehearsal_1.0.0_2026-06-29T11-21-19-689Z.zip
- PASS — evidence ZIP does not include source repo files — Bundle source is evidence folder only.
